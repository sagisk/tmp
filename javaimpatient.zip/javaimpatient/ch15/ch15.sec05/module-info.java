@SuppressWarnings("module")
module ch15.sec05 {
   requires com.horstmann.greet;
}
