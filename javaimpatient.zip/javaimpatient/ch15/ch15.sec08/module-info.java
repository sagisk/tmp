@SuppressWarnings("module")
module ch15.sec08 {
   requires commons.csv;
}
