@SuppressWarnings("module")
module ch15.sec04 {
	// Try commenting out the line below
    requires java.desktop;
}
