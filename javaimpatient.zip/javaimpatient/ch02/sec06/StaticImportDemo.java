package ch02.sec06;

import static java.lang.Math.*;

public class StaticImportDemo {
    public static void main(String[] args) {
        double r = 10;
        double area = 4 * PI * pow(r, 2);
        System.out.println(area);        
    }
}
